from . import myModule
from . import recursion.py
from . import sorting.py
